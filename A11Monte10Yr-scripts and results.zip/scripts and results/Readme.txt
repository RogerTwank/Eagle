Of the 100 randomized parameter sets simulated to one year, 
select the 10 with lowest perilune points during the first year.
Run those sets out to 10 years.
